require("dotenv").config();
const express = require("express");
const path = require("path");
const { Telegraf, Markup } = require("telegraf");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.BOT_TOKEN;
const WEBAPP_URL = process.env.WEBAPP_URL;
const BOT_USERNAME = (process.env.BOT_USERNAME || "YourBotUsername").replace(/^@/, "");

// DEMO ONLY: in-memory storage resets when server restarts.
// Replace with a database and verify Telegram initData before production use.
const users = new Map();
const tasks = [
  { id: "welcome", title: "Welcome to GB Coin", reward: 25, type: "daily" },
  { id: "community", title: "Join our Telegram community", reward: 100, type: "social" },
  { id: "daily", title: "Daily check-in", reward: 50, type: "daily" }
];

function getUser(id, name = "Miner") {
  if (!users.has(String(id))) {
    users.set(String(id), {
      id: String(id), name, balance: 0, mined: 0, referrals: 0,
      lastClaim: 0, completedTasks: [], referredBy: null
    });
  }
  return users.get(String(id));
}

app.get("/api/state", (req, res) => {
  // Demo endpoint. Production must authenticate the Telegram WebApp initData.
  const id = String(req.query.userId || "demo-user");
  const user = getUser(id, req.query.name || "GB Miner");
  res.json({ user, tasks, leaderboard: [...users.values()]
    .sort((a,b) => b.balance-a.balance).slice(0,10)
    .map(u => ({ name: u.name, balance: u.balance })) });
});

app.post("/api/mine", (req, res) => {
  const id = String(req.body.userId || "demo-user");
  const user = getUser(id);
  const now = Date.now();
  const cooldown = 60 * 60 * 1000;
  if (now - user.lastClaim < cooldown) {
    return res.status(429).json({ error: "Mining claim is on cooldown." });
  }
  user.balance += 10;
  user.mined += 10;
  user.lastClaim = now;
  res.json({ ok: true, user });
});

app.post("/api/daily", (req, res) => {
  const id = String(req.body.userId || "demo-user");
  const user = getUser(id);
  const today = new Date().toISOString().slice(0,10);
  if (user.lastDaily === today) return res.status(409).json({ error: "Daily bonus already claimed." });
  user.balance += 50;
  user.lastDaily = today;
  res.json({ ok: true, user });
});

app.post("/api/task", (req, res) => {
  const id = String(req.body.userId || "demo-user");
  const taskId = String(req.body.taskId || "");
  const user = getUser(id);
  const task = tasks.find(t => t.id === taskId);
  if (!task) return res.status(404).json({ error: "Task not found." });
  if (user.completedTasks.includes(taskId)) return res.status(409).json({ error: "Task already claimed." });
  user.completedTasks.push(taskId);
  user.balance += task.reward;
  res.json({ ok: true, user });
});

app.get("/api/referral/:userId", (req, res) => {
  const user = getUser(req.params.userId);
  res.json({ referrals: user.referrals, link: `https://t.me/${BOT_USERNAME}?start=${user.id}` });
});

if (BOT_TOKEN) {
  const bot = new Telegraf(BOT_TOKEN);
  bot.start((ctx) => {
    const id = String(ctx.from.id);
    const user = getUser(id, ctx.from.first_name || "Miner");
    const payload = ctx.startPayload;
    if (payload && payload !== id && !user.referredBy && users.has(String(payload))) {
      user.referredBy = String(payload);
      users.get(String(payload)).referrals += 1;
      users.get(String(payload)).balance += 100;
    }
    const url = WEBAPP_URL || "https://your-deployed-domain.example";
    return ctx.reply(
      "Welcome to GB Coin! Tap below to open the Mini App.",
      Markup.inlineKeyboard([[Markup.button.webApp("🚀 Open GB Coin", url)]])
    );
  });
  bot.launch().then(() => console.log("Telegram bot is running")).catch(console.error);
  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));
} else {
  console.log("BOT_TOKEN not set. API server only; Telegram bot is disabled.");
}

app.listen(PORT, () => console.log(`GB Coin server listening on ${PORT}`));
