# GB Coin Telegram Mini App — Starter

Green + Black themed Telegram Mini App starter with a small Express API and optional Telegram bot.

## Included
- Mining claim (+10 demo GB, one claim per hour)
- Daily bonus (+50 demo GB)
- Tasks and one-time task rewards
- Referral link / basic referral credit
- Leaderboard, profile, responsive mini-app UI
- Optional Telegram `/start` bot button

## Important limitations
This is a **starter/demo**, not a production token or payment system.
- Data is stored in RAM and resets when the server restarts.
- Telegram `initData` is **not validated** yet. The demo API accepts a user ID from the client and is not safe for real rewards.
- Social task completion is not independently verified.
- Referral anti-abuse, database, admin authentication, withdrawal processing, and on-chain token integration are not implemented.
- Never promise cash value or withdrawals unless you have a funded, tested, legally compliant payout system.

## Run locally
1. Install Node.js 18+.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env` and add your Telegram bot token.
4. Set `WEBAPP_URL` to your deployed HTTPS URL (for local UI testing, run without bot token).
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Connect Telegram
1. Create a bot using Telegram's official `@BotFather`.
2. Set `BOT_TOKEN` in `.env`.
3. Deploy this app to an HTTPS host and set `WEBAPP_URL`.
4. Restart the server and send `/start` to your bot.

## Before public launch
- Add persistent database storage (PostgreSQL/SQLite).
- Validate Telegram WebApp `initData` on the server for every API request.
- Add rate limits, unique referral attribution, fraud controls, and audit logs.
- Protect admin actions with server-side authorization using Telegram user IDs.
- Add clear Terms, Privacy Policy, tokenomics, and withdrawal rules.
- Test on a staging bot before announcing rewards.
